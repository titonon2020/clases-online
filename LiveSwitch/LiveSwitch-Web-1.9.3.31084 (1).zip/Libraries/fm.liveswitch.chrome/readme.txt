OPTIONAL: Modify manifest.json with your own contact information.

Create a zip archive to create the extension.